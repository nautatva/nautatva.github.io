#!/usr/bin/env python

import image
from helper import convert_to_png, path
from road_detection.detect import find_roads
from super_resolution import batch_SR

DEBUG = True
console_seperator = "*************************"

def main():
    """ Converts the source image into PNG, scales it down to 8 bit, splits the new image into small pieces, applies super-resolution, georeferences the processed image, tries to identify roads and stitches back the split image to get a network of roads. """

    # abs_root_path = path(os.getcwd(), 'test')
    root_path = "image/"
    image_name = "example"
    extension = ".tiff"
    src = path(root_path, image_name, extension)

    # slice images:
    df = image.split(src, path(root_path, "sliced"))
    print(console_seperator)
    print(df)
    print(console_seperator)

    # Super-resolution
    batch_SR(
        folder_path_in=path(root_path, "sliced"),
        folder_path_out=path(root_path, "sr"),
        extension=extension,
        SR_weight=path(root_path, "weights/sr_4x.h5"),
    )
    print(console_seperator)

    # Find roads
    find_roads(source=path(root_path, "sr"), output=path(root_path, "roads"), weights="weights/roads_dink32.th")
    print(console_seperator)

    # Merge images again
    df = image.merge(
        input_folder=path(root_path, "roads"),
        output_folder=path(root_path, "merged"),
        extension=extension,
        scale=1,
    )

    # Compress the output
    convert_to_png(path(path(root_path, "sr_merged"), image_name + extension))


if __name__ == "__main__":
    main()
