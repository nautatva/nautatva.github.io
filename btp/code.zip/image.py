import os
from time import time

import numpy as np
from helper import path, read_image, write_image

sep0 = "__"
sep1 = "_"


def split(
    src,
    destination,
    extension=".tiff",
    stride_x=540,
    stride_y=540,
    slice_x=544,
    slice_y=544,
):
    """Slice a single image or all images in given folder into small files."""

    isdir = os.path.isdir(src)
    if isdir and extension == "":
        raise ValueError(
            "Please provide a valid extension when images in folder is to be slices"
        )
    if isdir:
        print("Slicing images in:", src)
        images = [z for z in os.listdir(src) if z.endswith(extension)]
        # Add a . in case not present.
        extension = "." + extension.split(".")[-1]
    else:
        print("slicing image:", src)
        images = [src]
        extension = "." + src.split(".")[-1]

    t0 = time()
    count = 0
    csv, name_list = [], []

    for i, image in enumerate(images):
        print(i + 1, "/", len(images), "image_path:", image)
        file_name = os.path.basename(image).split(".")[0]

        im = read_image(image)
        print(im.shape)
        h, w, nbands = im.shape

        seen_coords = set()

        for x in range(0, w, stride_x):
            for y in range(0, h, stride_y):
                xmin = max(0, min(x, w - slice_x))
                ymin = max(0, min(y, h - slice_y))
                coords = (xmin, ymin)

                # check if we've already seen these coords
                if coords in seen_coords:
                    continue
                else:
                    seen_coords.add(coords)

                # check if we binned up correctly
                if (slice_x <= w and (xmin + slice_x > w)) or (
                    slice_y <= h and (ymin + slice_y > h)
                ):
                    print("Improperly binned image,")
                    return

                # get satellite image cutout
                im_cutout = im[ymin : ymin + slice_y, xmin : xmin + slice_x]

                ##############
                # skip if the whole thing is black
                if np.max(im_cutout) < 1.0:
                    continue
                else:
                    count += 1

                if (count % 50) == 0:
                    print("count:", count, "x:", x, "y:", y)
                ###############

                # set slice name
                name_full = (
                    file_name
                    + sep0
                    + str(ymin)
                    + sep1
                    + str(xmin)
                    + sep1
                    + str(slice_y)
                    + sep1
                    + str(slice_x)
                    + sep1
                    + str(0)
                    + sep1
                    + str(w)
                    + sep1
                    + str(h)
                    + extension
                )

                name_out = path(destination, name_full)
                write_image(im_cutout, name_out)

                csv_column = [
                    i + 1,
                    file_name,
                    name_out,
                    xmin,
                    ymin,
                    slice_x,
                    slice_y,
                    w,
                    h,
                ]
                # add to arrays
                name_list.append(name_out)
                csv.append(csv_column)

    csv_columns = [
        "idx",
        "name",
        "name_out",
        "xmin",
        "ymin",
        "slice_x",
        "slice_y",
        "im_x",
        "im_y",
    ]

    print("Time to slice arrays:", time() - t0, "seconds")

    df_csv = path(destination, file_name + "_df.csv")
    # save to file
    data = np.row_stack((csv_columns, csv))
    np.savetxt(df_csv, data, delimiter=",", fmt="%s")

    print("df saved to file:", df_csv)

    return data


def merge(input_folder, output_folder, extension=".tiff", scale=4, verbose=False):
    """
    Gives 3 images: raw, count, norm
    """
    n_bands = 3  # RGB

    # get image names
    slice_names = sorted([z for z in os.listdir(input_folder) if z.endswith(extension)])
    image_names = np.sort(np.unique([z.split(sep0)[0] for z in slice_names]))
    if verbose:
        print("image_names:", image_names)

    for i, name_root in enumerate(image_names):
        print(i + 1, "/", len(image_names), "  ", name_root + extension)
        im_name, im_norm, im_raw, overlay_count = _post_process_image_name(
            name_root,
            input_folder,
            n_bands=n_bands,
            extension=extension,
            size_mult=scale,
            verbose=verbose,
        )

        # save files
        write_image(im_norm, path(output_folder, im_name + extension))
        write_image(im_raw, path(output_folder, im_name + "_raw" + extension))
        # write_image(overlay_count, path(output_folder,
        # im_name + '_overlay' + extension))

        del im_norm
        del im_raw
        del overlay_count


def _post_process_image_name(
    name, data_dir, size_mult=4, n_bands=3, extension=".tiff", verbose=False
):
    """
    From an image name and a data_dir,
    image names are assumed to have the format below (as in split function before in this notebook):
        outpath = os.path.join(chip_outdir, out_name + \
            '__' + str(y) + '_' + str(x) + '_' + str(sliceHeight) + '_' + str(sliceWidth) +\
            '_' + str(pad) + '_' + str(win_w) + '_' + str(win_h) + ext)

    Assume image is being resized by super-resolution, so the slices have been
      resized by a factor of size_mult (e.g. 4x super res has size_mult = 4)

    """
    im_slice_names = sorted(
        [
            z
            for z in os.listdir(data_dir)
            if (z.startswith(name + sep0) and z.endswith(extension))
        ]
    )

    im_slice_name_ex = im_slice_names[0].split(extension)[0]
    im_name, vals = im_slice_name_ex.split(sep0)
    ymin, xmin, slice_y, slice_x, pad, im_x, im_y = [int(z) for z in vals.split(sep1)]

    # get image width and height
    w, h = im_x * size_mult, im_y * size_mult

    if verbose:
        print("im_slice_name_ex:", im_slice_name_ex)
        print("vals:", vals)
        print("w, h, n_bands:", w, h, n_bands)
        print(
            f"[int(z) for z in vals.split(${sep1})]:",
            [int(z) for z in vals.split(sep1)],
        )

    # create numpy zeros of appropriate shape
    im_raw = np.zeros((h, w, n_bands))  # dtype=np.uint16)
    overlay_count = np.zeros((h, w), dtype=np.uint8)  # dtype=np.uint16)

    # iterate through slices
    for i, name_full in enumerate(im_slice_names):
        if (i % 100) == 0:
            print("  ", i + 1, "/", len(im_slice_names))

        im_slice_name_ex = name_full.split(extension)[0]
        if verbose:
            print("im_slice_name_ex: ", im_slice_name_ex)
        im_name, vals = im_slice_name_ex.split(sep0)
        ymin, xmin, slice_y, slice_x, pad, im_x, im_y = [
            size_mult * int(z) for z in vals.split(sep1)
        ]

        # read in image
        if n_bands == 3:
            im_slice_refine = read_image(path(data_dir, name_full))
        else:
            raise ValueError("Cannot have any other number as RGB are only 3 bands")

        if verbose:
            print("vals:", vals)
        if slice_x > im_x:
            slice_x = im_x
        if slice_y > im_y:
            slice_y = im_y

        x0, x1 = xmin, xmin + slice_x
        y0, y1 = ymin, ymin + slice_y

        if verbose:
            print("name_full:", name_full)
            print("im_slice_refine.shape:", im_slice_refine.shape)
            print("im_raw.shape:", im_raw.shape)
            print("im_x, im_y:", im_x, im_y)
            print("x0, y0, x1, y1:", x0, y0, x1, y1)

        # add data to im_raw for each band
        for j in range(n_bands):
            # replace the j with :
            im_raw[y0:y1, x0:x1, j] += im_slice_refine[:, :, j]

        # update count
        overlay_count[y0:y1, x0:x1] += np.ones((slice_y, slice_x), dtype=np.uint8)

    # compute normalized im
    overlay_count[np.where(overlay_count == 0)] = 1

    #  = create another zero array to record which pixels are overlaid
    im_norm = np.zeros((h, w, n_bands))

    # throws a memory error if using np.divide...
    if h < 60000:
        for j in range(n_bands):
            im_norm[:, :, j] = np.divide(im_raw[:, :, j], overlay_count)
    else:
        for j in range(h):
            im_norm[j] = int(im_raw[j] / overlay_count[j])

    dtype = im_slice_refine.dtype
    return (
        im_name,
        im_norm.astype(dtype),
        im_raw.astype(dtype),
        overlay_count.astype(np.uint8),
    )
