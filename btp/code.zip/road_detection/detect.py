import pickle
from os import listdir
from time import time

import cv2
import torch
import torch.nn as nn
import torch.utils.data as data
from torch.autograd import Variable as V

import numpy as np
from helper import path

# from networks.unet import Unet
# from networks.dunet import Dunet
from .networks.dinknet import DinkNet34

BATCHSIZE_PER_CARD = 2


class TTAFrame:
    def __init__(self, net):
        self.net = net()
        self.net = torch.nn.DataParallel(
            self.net, device_ids=list(range(torch.get_num_threads()))
        )

    def test_one_img_from_path(self, path, evalmode=True):
        if evalmode:
            self.net.eval()
        batchsize = torch.get_num_threads() * BATCHSIZE_PER_CARD
        if batchsize >= 8:
            return self.test_one_img_from_path_1(path)
        elif batchsize >= 4:
            return self.test_one_img_from_path_2(path)
        elif batchsize >= 2:
            return self.test_one_img_from_path_4(path)

    def test_one_img_from_path_8(self, path):
        img = cv2.imread(path)  # .transpose(2,0,1)[None]
        img90 = np.array(np.rot90(img))
        img1 = np.concatenate([img[None], img90[None]])
        img2 = np.array(img1)[:, ::-1]
        img3 = np.array(img1)[:, :, ::-1]
        img4 = np.array(img2)[:, :, ::-1]

        img1 = img1.transpose(0, 3, 1, 2)
        img2 = img2.transpose(0, 3, 1, 2)
        img3 = img3.transpose(0, 3, 1, 2)
        img4 = img4.transpose(0, 3, 1, 2)

        img1 = V(torch.Tensor(np.array(img1, np.float32) / 255.0 * 3.2 - 1.6))
        img2 = V(torch.Tensor(np.array(img2, np.float32) / 255.0 * 3.2 - 1.6))
        img3 = V(torch.Tensor(np.array(img3, np.float32) / 255.0 * 3.2 - 1.6))
        img4 = V(torch.Tensor(np.array(img4, np.float32) / 255.0 * 3.2 - 1.6))

        maska = self.net.forward(img1).squeeze().data.numpy()
        maskb = self.net.forward(img2).squeeze().data.numpy()
        maskc = self.net.forward(img3).squeeze().data.numpy()
        maskd = self.net.forward(img4).squeeze().data.numpy()

        mask1 = maska + maskb[:, ::-1] + maskc[:, :, ::-1] + maskd[:, ::-1, ::-1]
        mask2 = mask1[0] + np.rot90(mask1[1])[::-1, ::-1]

        return mask2

    def test_one_img_from_path_4(self, path):
        img = cv2.imread(path)  # .transpose(2,0,1)[None]
        img90 = np.array(np.rot90(img))
        img1 = np.concatenate([img[None], img90[None]])
        img2 = np.array(img1)[:, ::-1]
        img3 = np.array(img1)[:, :, ::-1]
        img4 = np.array(img2)[:, :, ::-1]

        img1 = img1.transpose(0, 3, 1, 2)
        img2 = img2.transpose(0, 3, 1, 2)
        img3 = img3.transpose(0, 3, 1, 2)
        img4 = img4.transpose(0, 3, 1, 2)

        img1 = V(torch.Tensor(np.array(img1, np.float32) / 255.0 * 3.2 - 1.6))
        img2 = V(torch.Tensor(np.array(img2, np.float32) / 255.0 * 3.2 - 1.6))
        img3 = V(torch.Tensor(np.array(img3, np.float32) / 255.0 * 3.2 - 1.6))
        img4 = V(torch.Tensor(np.array(img4, np.float32) / 255.0 * 3.2 - 1.6))

        maska = self.net.forward(img1).squeeze().data.numpy()
        maskb = self.net.forward(img2).squeeze().data.numpy()
        maskc = self.net.forward(img3).squeeze().data.numpy()
        maskd = self.net.forward(img4).squeeze().data.numpy()

        mask1 = maska + maskb[:, ::-1] + maskc[:, :, ::-1] + maskd[:, ::-1, ::-1]
        mask2 = mask1[0] + np.rot90(mask1[1])[::-1, ::-1]

        return mask2

    def test_one_img_from_path_2(self, path):
        img = cv2.imread(path)  # .transpose(2,0,1)[None]
        img90 = np.array(np.rot90(img))
        img1 = np.concatenate([img[None], img90[None]])
        img2 = np.array(img1)[:, ::-1]
        img3 = np.concatenate([img1, img2])
        img4 = np.array(img3)[:, :, ::-1]
        img5 = img3.transpose(0, 3, 1, 2)
        img5 = np.array(img5, np.float32) / 255.0 * 3.2 - 1.6
        img5 = V(torch.Tensor(img5))
        img6 = img4.transpose(0, 3, 1, 2)
        img6 = np.array(img6, np.float32) / 255.0 * 3.2 - 1.6
        img6 = V(torch.Tensor(img6))

        maska = self.net.forward(img5).squeeze().data.numpy()  # .squeeze(1)
        maskb = self.net.forward(img6).squeeze().data.numpy()

        mask1 = maska + maskb[:, :, ::-1]
        mask2 = mask1[:2] + mask1[2:, ::-1]
        mask3 = mask2[0] + np.rot90(mask2[1])[::-1, ::-1]

        return mask3

    def test_one_img_from_path_1(self, path):
        img = cv2.imread(path)  # .transpose(2,0,1)[None]

        img90 = np.array(np.rot90(img))
        img1 = np.concatenate([img[None], img90[None]])
        img2 = np.array(img1)[:, ::-1]
        img3 = np.concatenate([img1, img2])
        img4 = np.array(img3)[:, :, ::-1]
        img5 = np.concatenate([img3, img4]).transpose(0, 3, 1, 2)
        img5 = np.array(img5, np.float32) / 255.0 * 3.2 - 1.6
        img5 = V(torch.Tensor(img5))

        mask = self.net.forward(img5).squeeze().data.numpy()  # .squeeze(1)
        mask1 = mask[:4] + mask[4:, :, ::-1]
        mask2 = mask1[:2] + mask1[2:, ::-1]
        mask3 = mask2[0] + np.rot90(mask2[1])[::-1, ::-1]

        return mask3

    def load(self, path):
        self.net.load_state_dict(torch.load(path, map_location="cpu"))


def find_road(im_in, im_out, weights="weights/roads_dink34.th"):
    solver = TTAFrame(DinkNet34)
    solver.load(weights)
    mask = solver.test_one_img_from_path(im_in)
    mask[mask > 4.0] = 255
    mask[mask <= 4.0] = 0
    mask = np.concatenate(
        [mask[:, :, None], mask[:, :, None], mask[:, :, None]], axis=2
    )
    cv2.imwrite(im_out, mask.astype(np.uint8))


def find_roads(source, output, weights="weights/roads_dink34.th"):
    """
    Tries to find roads in all images of a folder. Image resolution must be divisible by 32.
    """
    val = [item for item in listdir(source) if item not in listdir(output)]
    tic = time()

    for i, name in enumerate(val):
        # Must be square image with pixels divisible by 16
        print("Doing ", path(source, name))
        find_road(path(source, name), path(output, name))
        # if i%10 == 0:
        print(i, " ", output + name, "    ", "%.2f" % (time() - tic))
