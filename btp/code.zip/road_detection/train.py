import os
from time import time

import cv2
import torch
import torch.nn as nn
import torch.utils.data as data
from torch.autograd import Variable as V

import numpy as np
from data import ImageFolder
from framework import MyFrame
from loss import dice_bce_loss
from networks.dinknet import (
    DinkNet34,
    DinkNet34_less_pool,
    DinkNet50,
    DinkNet101,
    LinkNet34,
)
from networks.dunet import Dunet
from networks.unet import Unet

SHAPE = (1024, 1024)
ROOT = "dataset/train/"
imagelist = [x for x in os.listdir(ROOT) if x.find("sat") != -1]
trainlist = [x[:-8] for x in imagelist]
NAME = "log01_dink34"
BATCHSIZE_PER_CARD = 4

solver = MyFrame(DinkNet34, dice_bce_loss, 2e-4)
batchsize = torch.get_num_threads() * BATCHSIZE_PER_CARD

dataset = ImageFolder(trainlist, ROOT)
data_loader = torch.utils.data.DataLoader(
    dataset, batch_size=batchsize, shuffle=True, num_workers=4
)

mylog = open("logs/" + NAME + ".log", "w")
tic = time()
no_optim = 0
total_epoch = 300
train_epoch_best_loss = 100.0
for epoch in range(1, total_epoch + 1):
    data_loader_iter = iter(data_loader)
    train_epoch_loss = 0
    for img, mask in data_loader_iter:
        solver.set_input(img, mask)
        train_loss = solver.optimize()
        train_epoch_loss += train_loss
    train_epoch_loss /= len(data_loader_iter)
    print("********", file=mylog)
    print("epoch:", epoch, "    time:", int(time() - tic), file=mylog)
    print("train_loss:", train_epoch_loss, file=mylog)
    print("SHAPE:", SHAPE, file=mylog)
    print("********")
    print("epoch:", epoch, "    time:", int(time() - tic))
    print("train_loss:", train_epoch_loss)
    print("SHAPE:", SHAPE)

    if train_epoch_loss >= train_epoch_best_loss:
        no_optim += 1
    else:
        no_optim = 0
        train_epoch_best_loss = train_epoch_loss
        solver.save("weights/" + NAME + ".th")
    if no_optim > 6:
        print("early stop at %d epoch" % epoch, file=mylog)
        print("early stop at %d epoch" % epoch)
        break
    if no_optim > 3:
        if solver.old_lr < 5e-7:
            break
        solver.load("weights/" + NAME + ".th")
        solver.update_lr(5.0, factor=True, mylog=mylog)
    mylog.flush()

print("Finish!", file=mylog)
print("Finish!")
mylog.close()
