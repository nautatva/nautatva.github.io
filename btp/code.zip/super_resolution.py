from os import listdir
from os.path import exists

from helper import path, read_image, write_image
from numpy import array
from tensorflow import as_dtype, cast, clip_by_value, expand_dims, float32, round
from tensorflow.python.keras.layers import Add, Conv2D, Input, Lambda
from tensorflow.python.keras.models import Model
from tensorflow.python.ops.array_ops import depth_to_space

DIV2K_RGB_MEAN = array([0.4488, 0.4371, 0.4040])  # Multiply with depth


def _normalize(
    x, maxx=255, rgb_mean=DIV2K_RGB_MEAN,
):
    rgb_mean = rgb_mean * maxx
    return (x - rgb_mean) / (maxx / 2.0)


def _denormalize(
    x, maxx=255, rgb_mean=DIV2K_RGB_MEAN,
):
    return x * (maxx / 2.0) + rgb_mean * maxx


def _pixel_shuffle(scale):
    return lambda x: depth_to_space(x, scale)


def _upsample(x, scale, num_filters):
    def upsample_1(x, factor, **kwargs):
        x = Conv2D(num_filters * (factor ** 2), 3, padding="same", **kwargs)(x)
        return Lambda(_pixel_shuffle(scale=factor))(x)

    if scale == 2:
        x = upsample_1(x, 2, name="conv2d_1_scale_2")
    elif scale == 3:
        x = upsample_1(x, 3, name="conv2d_1_scale_3")
    elif scale == 4:
        x = upsample_1(x, 2, name="conv2d_1_scale_2")
        x = upsample_1(x, 2, name="conv2d_2_scale_2")

    return x


def _res_block(x_in, filters, scaling):
    """
    Residual block
    """
    x = Conv2D(filters, 3, padding="same", activation="relu")(x_in)
    x = Conv2D(filters, 3, padding="same")(x)
    if scaling:
        x = Lambda(lambda t: t * scaling)(x)
    x = Add()([x_in, x])
    return x


def _edsr(scale, maxx=255, num_filters=64, num_res_blocks=8, res_block_scaling=None):
    x_in = Input(shape=(None, None, 3))
    x = Lambda(_normalize, arguments={"maxx": maxx})(x_in)

    x = b = Conv2D(num_filters, 3, padding="same")(x)
    for i in range(num_res_blocks):
        b = _res_block(b, num_filters, res_block_scaling)

    b = Conv2D(num_filters, 3, padding="same")(b)
    x = Add()([x, b])

    x = _upsample(x, scale, num_filters)
    x = Conv2D(3, 3, padding="same")(x)

    x = Lambda(_denormalize, arguments={"maxx": maxx})(x)
    return Model(x_in, x, name="edsr")


def _resolve_single(model, lr, dtype):
    def _resolve(model, lr_batch):
        lr_batch = cast(lr_batch, float32)
        sr_batch = model(lr_batch)
        # scale to dtype.min to dtype.max
        sr_batch = clip_by_value(sr_batch, 0, dtype.max)
        sr_batch = round(sr_batch)
        sr_batch = cast(sr_batch, dtype)
        return sr_batch

    return _resolve(model, expand_dims(lr, axis=0))[0]


def apply_sr(image_in, image_out, SR_weight):
    """
      Apply super-resolution to make image finer. Image must be a square and each side pixel number must be divisible by 16 #TODO: check by 8
    """
    if not exists(SR_weight):
        raise ValueError("Weights not found at " + SR_weight)
    lr = read_image(image_in)
    dtype = as_dtype(lr.dtype)
    modele = _edsr(scale=4, num_res_blocks=16, maxx=dtype.max)
    modele.load_weights(SR_weight)

    sre = _resolve_single(modele, lr, dtype)
    write_image(sre.numpy(), path(image_out))


def batch_SR(folder_path_in, folder_path_out, extension, SR_weight):
    """
    Apply super-resolution to every image in a folder with given extension. Saves the finer image in path given by folder_path_out with same name.
    """
    im_roots = [z for z in listdir(folder_path_in) if z.endswith(extension)]
    already_present = [z for z in listdir(folder_path_out) if z.endswith(extension)]
    left_images = array(list(filter(lambda x: x not in already_present, im_roots)))
    print("total images to be processed for SR: ", len(im_roots))
    print("total images already processed for SR: ", len(already_present))
    print("total images left for processing for SR: ", len(left_images))

    for i, left_image in enumerate(left_images):
        print(i + 1, "/", len(left_images), "image:", left_image)
        apply_sr(
            image_in=path(folder_path_in, left_image),
            image_out=path(folder_path_out, left_image),
            SR_weight=SR_weight,
        )
