import os

from skimage.io import imread

from numpy import array, iinfo, zeros
from osgeo import gdal

switcher = {
    "uint8": gdal.GDT_Byte,
    "int8": gdal.GDT_Byte,
    "uint16": gdal.GDT_UInt16,
    "int16": gdal.GDT_Int16,
    "uint32": gdal.GDT_UInt32,
    "int32": gdal.GDT_Int32,
    "float32": gdal.GDT_Float32,
    "float64": gdal.GDT_Float64,
    "complex64": gdal.GDT_CFloat64,
}


def path(root_path, second_name="", extension=""):
    """ Returns relative path of the file or a folder after os.join. Creates the folder if folder not found """
    if not second_name and not extension:
        return root_path
    if extension != "" or "." in second_name:
        # given path is a file or a symbolic link
        if "./" in second_name:
            return os.path.realpath(os.path.join(root_path, second_name + extension))
        return os.path.join(root_path, second_name + extension)

    new_path = os.path.join(root_path, second_name)
    if not os.path.exists(new_path):
        os.mkdir(new_path)
    return new_path


def absolute_path(root_path, second_name="", extension=""):
    """ Returns the absolute path of the file or a folder after os.join. Creates the folder if folder not found. """
    return os.path.realpath(path(root_path, second_name, extension))


def getDriver(src):
    """ Gets the driver as found by gdalInfo """
    s = gdal.Info(src)
    q = "Driver: "
    return s[s.find(q) + len(q) :].split()[0].split("/")[0]


def convertToPNG(destination, src):
    """ Converts image from to the specified type """
    gdal.Translate(destination, src)


def read_image(
    file_name, verbose=False,
):
    """
    Reads an image file, returns a numpy array; ignores the alpha layer
    """
    temp_image = imread(file_name)
    h, w, channels = temp_image.shape

    if channels == 4:
        image = zeros((h, w, 3), dtype=temp_image.dtype)
        # Skip alpha layer
        for i in range(3):
            image[:, :, i] = temp_image[:, :, i][::-1]
        return image

    return temp_image


def write_image(image_array, file_name):
    if len(image_array.shape) == 2:
        (h, w) = image_array.shape
        dst_ds = gdal.GetDriverByName("GTiff").Create(
            file_name, w, h, 1, switcher[str(image_array.dtype)]
        )
        dst_ds.GetRasterBand(1).WriteArray(image_array[:, :])  # only 1 band - b/w
    elif len(image_array.shape) == 3:
        (h, w, nbands) = image_array.shape
        dst_ds = gdal.GetDriverByName("GTiff").Create(
            file_name, w, h, nbands, switcher[str(image_array.dtype)]
        )
        dst_ds.GetRasterBand(1).WriteArray(
            image_array[:, :, 0]
        )  # write r-band to the raster
        dst_ds.GetRasterBand(2).WriteArray(
            image_array[:, :, 1]
        )  # write g-band to the raster
        dst_ds.GetRasterBand(3).WriteArray(
            image_array[:, :, 2]
        )  # write b-band to the raster
    else:
        raise ValueError("Only 1 channel or RGB image supported")
    dst_ds.FlushCache()  # write to disk
    dst_ds = None  # save, close


def convertTo8Bit(destination, src):
    """ Converts the given 16 bit image to 8 bit. """
    dtype_max = iinfo(read_image(src).dtype).max
    os.system(
        f"gdal_translate -of {getDriver(src)} -ot Byte -scale 0 {dtype_max} 0 255 {src} {destination}"
    )


def batch(
    function,
    folder_path_in,
    folder_path_out,
    extension="",
    iterating_input_param="",
    iterating_output_param="",
    pass_extension=False,
    continued=True,
    **kwargs,
):
    """
    Takes a function and performs a function for complete folder.
    """
    files = [z for z in os.listdir(folder_path_in) if z.endswith(extension)]
    print(files)
    left_files = files
    if continued:
        already_present = [
            z for z in os.listdir(folder_path_out) if z.endswith(extension)
        ]
        left_files = array(list(filter(lambda x: x not in already_present, files)))
    if pass_extension:
        kwargs["extension"] = extension

    print("To be processed: ", len(files))
    print("Already processed: ", len(already_present))
    print("left for processing: ", len(left_files))

    for i, left_file in enumerate(left_files):
        print(i + 1, "/", len(left_files), "image:", left_file)
        iteration_param = {}
        if iterating_input_param is not None:
            iteration_param[iterating_input_param] = path(folder_path_in, left_file)
        if iterating_output_param is not None:
            iteration_param[iterating_output_param] = path(folder_path_out, left_file)
        function(**iteration_param, **kwargs)


def convert_to_png(src, remove=True):
    "Converts an image to PNG, also compresses it in a lossless fashion. Removes the original image. Also removes the original file if not mentioned explicitly"
    os.system(f"gdal_translate -co 'COMPRESS=lossless' {src} {src.split('.')[0]}.png")
    if remove:
        os.remove(src)
